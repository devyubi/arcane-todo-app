import TaskPageSection from "@/features/tasks/components/TaskPageSection";

export default function Page() {
  return (
    <main className="container">
      <TaskPageSection />
    </main>
  );
}
